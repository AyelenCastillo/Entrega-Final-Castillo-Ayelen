
class Cliente:
    def __init__(self, nombre, email, telefono, direccion):
        self.nombre = nombre
        self.email = email
        self.telefono = telefono
        self.direccion = direccion

    def __str__(self):
        return f"Nombre: {self.nombre}, Email: {self.email}, Teléfono: {self.telefono}, Dirección: {self.direccion}"

    def realizar_compra(self, producto):
        print(f"{self.nombre} ha comprado {producto}.")