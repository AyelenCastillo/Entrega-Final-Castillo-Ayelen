from setuptools import setup

setup(
    name='paquete',
    version='1.0',
    description="Paquete realizado para la segunda entrega del curso de Python",
    packages=['paquete'],        

)